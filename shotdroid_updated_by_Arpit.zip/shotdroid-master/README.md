# ShotDroid v2

ShotDroid is a pentesting tool for android. There are 3 tools that have their respective functions:
 - **Android Files :** Get files from Android directory, internal and external storage (Images, Videos, Whatsapp, ..)
 - **Android Keylogger :** Android Keylogging Keyboard + Reverse Shell.
 - **Take Face Webcam :** Take face shot from the target phone's front camera and PC webcam.
 
 ![Screenshot from 2021-02-15 00-55-38](https://user-images.githubusercontent.com/58439463/107884649-b15d7880-6f28-11eb-929e-1f39e37e1f0e.png)
 
## Features !
 - Hide apps in android files.
 - Custom android directory.
 - For Android Keylogger -> you can see it here: [**Simple-keyboard**](https://github.com/rkkr/simple-keyboard/) or [**LokiBoard.**](https://github.com/IceWreck/LokiBoard-Android-Keylogger)
 - Automatic html template in take face webcam.
 - Custom html or custom your html folder in take face webcam tool.
 - etc.
 
## Information:
This tool is for educational purpose only, usage of SHOTDROID for attacking targets without prior mutual consent is illegal. Developers assume no liability and are not responsible for any misuse or damage cause by this program.
 
## Requirements:
 - android studio (https://developer.android.com/studio)
 - ngrok (https://ngrok.com/download)
 - php
 - xterm
 - zenity

## Usage:
```bash
git clone https://github.com/by Arpit/shotdroid.git
cd shotdroid
bash shotdroid.sh
```

### Video Demo: 
- Android Files: [Kali Tutorial](https://www.youtube.com/watch?v=9eGniotVgKg)
- Android Keylogger: [Kali Tutorial](https://www.youtube.com/watch?v=l-9YhrKonDY)

## Credits & Thanks:
***Buy me a coffee! :coffee:***
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://ko-fi.com/kalitutorial)

 - Buy me a coffee - [Kp300](https://ko-fi.com/kalitutorial)
 - LokiBoard - [LokiBoard](https://github.com/IceWreck/LokiBoard-Android-Keylogger)
 - Simple-keyboard - [Simple-keyboard](https://github.com/rkkr/simple-keyboard/)
 - @thelinuxchoice
